https://unipython.com/login-en-php-con-base-de-datos-mysql/
https://www.w3schools.com/php/php_mysql_prepared_statements.asp