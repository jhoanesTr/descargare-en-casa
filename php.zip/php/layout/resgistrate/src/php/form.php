<?php
//Declaramos variables
$nombre = $_POST['nombre'];
$apellidos = $_POST['apellidos'];
$usuario = $_POST['usuario'];
$email = $_POST['email'];
$contraseña = $_POST['contraseña'];
$contraseñar = $_POST['contraseñar'];
$telefono = $_POST['telefono'];


