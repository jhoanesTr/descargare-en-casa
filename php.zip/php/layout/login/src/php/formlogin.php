<?php
//Declaramos Variables
$usuario;
$contraseña;